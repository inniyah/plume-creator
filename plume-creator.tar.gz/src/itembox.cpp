#include "itembox.h"
//
ItemBox::ItemBox(QWidget *parent) :
    QFrame(parent)
{
}
